# Untuk rename semua file dari satu extensi ke extensi yang lain
find . -type f -follow -name "*.html" -exec rename 's/html/bersih.dat/' '{}' \;

# count file dalam semua folder pada path yang diberikan
# deep 2 folder karena */* 
for D in */*; do printf "$D : "; find $D -type f| wc -l; done